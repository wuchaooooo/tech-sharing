package com.wuchaooooo.open.aqs.lock;

import java.util.concurrent.atomic.AtomicReference;

/**
 * Spin Lock
 *
 * 自旋锁是指当一个线程尝试获取某个锁时，如果该锁已被其他线程占用，就一直循环检测锁是否被释放，而不是让线程阻塞或等待
 *
 * 自旋锁适用于锁保护的临界区很小的情况，临界区很小的话，锁占用的时间就很短
 *
 * 缺点：
 *     CAS操作需要硬件配合；
 *     保证各个CPU的缓存（L1、L2、L3、跨CPU Socket、主存）的数据一致性，通讯开销很大，在多处理器系统上更严重；
 *     没法保证公平性，不保证等待进程/线程按照FIFO顺序获得锁（为了解决这个问题，有了下面的ticket lock）
 */
public class SpinLock {
    private AtomicReference<Thread> owner = new AtomicReference<>();

    public void lock() {
        Thread currentThread = Thread.currentThread();
        while (!owner.compareAndSet(null, currentThread)) {

        }
    }

    public void unlock() {
        Thread currentThread = Thread.currentThread();
        owner.compareAndSet(currentThread, null);
    }
}
