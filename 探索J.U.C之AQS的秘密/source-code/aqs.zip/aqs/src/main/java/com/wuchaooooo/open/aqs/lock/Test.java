package com.wuchaooooo.open.aqs.lock;

public class Test {

    private static int count;

    public static void main(String[] args) {


//        CLHLock lock = new CLHLock();
        SpinLock lock = new SpinLock();

        for (int i = 0; i < 1000; i++) {
            new Thread(() -> {
                lock.lock();
                count++;
                System.out.println(count);
                lock.unlock();
            }).start();
        }
    }
}