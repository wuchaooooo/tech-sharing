package com.wuchaooooo.open.aqs.lock;


import java.util.concurrent.atomic.AtomicReference;

/**
 * CLH的发明人是：Craig，Landin and Hagersten。
 *
 * CLH锁也是一种基于链表的可扩展、高性能、公平的自旋锁，申请线程只在本地变量上自旋，
 * 它不断轮询前驱的状态，如果发现前驱释放了锁就结束自旋。
 */
public class CLHLock {
    private final ThreadLocal<Node> prev; //保存当前线程的前继节点
    private final ThreadLocal<Node> node; //保存当前线程的节点

    //类在初始化时会初始化tail节点，相当于head节点(注意对隐式队列的理解)
    private final AtomicReference<Node> tail = new AtomicReference<Node>(new Node());

    public CLHLock() {
        this.prev = new ThreadLocal<Node>() {
            @Override
            protected Node initialValue() {
                return null;
            }
        };
        this.node = new ThreadLocal<Node>() {
            @Override
            protected Node initialValue() {
                return new Node();
            }
        };
    }

    public void lock() {
        Node node = this.node.get(); //获取Threadlocal变量，每个线程私有
        node.lock = true;
        //CAS方式设置tail节点，设置成功，相当于加入队列
        Node pred = this.tail.getAndSet(node);
        //把之前的tail节点，存入自己的prev节点，并循环访问其lock标志位，等待释放
        this.prev.set(pred);
        while (pred.lock) ;
    }

    public void unlock() {
        Node node = this.node.get();
        node.lock = false;
        //线程释放锁之后，将当前节点设置为前继节点，相当于队列的出队（利于GC）
        this.node.set(this.prev.get());
    }

    private class Node {
        //默认初始化值为false
        private volatile boolean lock;
    }

}
